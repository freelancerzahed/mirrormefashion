// config.ts
export const BACKEND_URL = process.env.NEXT_PUBLIC_BACKEND_URL || "http://mirrormefashion.com/api/v2";

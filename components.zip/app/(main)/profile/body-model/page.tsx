"use client"

import { useState, useRef, useEffect } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Progress } from "@/components/ui/progress"
import { useToast } from "@/hooks/use-toast"
import { modelLoader } from "@/lib/modelLoader"
import * as THREE from "three";
import {
  User,
  Ruler,
  Target,
  TrendingUp,
  Heart,
  Share2,
  Download,
  Zap,
  Calendar,
  Activity,
  Info,
  Eye,
  EyeOff,
  Copy,
  Facebook,
  Twitter,
  Instagram,
  Mail,
  Settings,
  Pencil,
  RotateCcw,
} from "lucide-react"
import { useIsMobile } from "@/hooks/use-mobile"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"

// Mock user data - in real app this would come from API/database
const mockUserData = {
  name: "Sarah Johnson",
  email: "sarah.johnson@example.com",
  avatar: "/placeholder.svg?height=100&width=100",
  createdAt: "2024-01-15",
  lastUpdated: "2024-01-20",
  bodyType: "Hourglass",
  confidence: 92,
  measurements: {
    height: 168,
    weight: 65,
    bust: 36,
    waist: 26,
    hips: 36,
    shoulders: 38,
  },
  bmi: 23.0,
  bodyFat: 22,
  muscleMass: 45,
}

// Full shape key map
const shapeKeyValues: Record<string, number> = {
  head_size: 0.75,
  shape_head_oblong: 1,
  shape_head_round: 0,
  neck_height: 0.75,
  neck_width: 0.5,
  neck_layers: 1,
  chin_shape: 1,
  trapezoid: 0.5,
  shoulder_height: 1,
  shoulder_width: 0.75,
  stomach_width_average: 0.75,
  stomach_width_pouch: 0,
  stomach_width_spoon: 0,
  stomach_width_rectangle: 0,
  stomach_width_pregnant: 0,
  trimester: 0.999,
  arm_size: 0,
  arms_distended: 0,
  breasts: 0.625,
  shape_stomach_curvy: 0,
  shape_stomach_MT: 0,
  shape_stomach_spoon: 0,
  shape_stomach_rectangle: 0,
  shape_stomach_pouch: 0,
  shape_stomach_pregnant: 1,
  torso_height: 0,
  crotch_height: 0,
  leg_height: 0,
  leg_size: 0,
  hips_size: 0,
  bottom_width: 0,
  bottom_shape_round: 0,
  bottom_shape_square: 0,
  bottom_shape_inverted: 0,
  bottom_shape_flat: 0,
  bottom_shape_heart: 0,
  bottom_shape_dunk: 0,
}

export default function BodyShapePage() {
  const isMobile = useIsMobile()
  const { toast } = useToast()
  const [showMeasurements, setShowMeasurements] = useState(true)
  const [activeTab, setActiveTab] = useState("overview")
  const [isFavorited, setIsFavorited] = useState(false)
  const [shareDialogOpen, setShareDialogOpen] = useState(false)
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const loaderRef = useRef<ReturnType<typeof modelLoader> | null>(null)

  // Load 3D model and apply shape keys
  useEffect(() => {
    if (!canvasRef.current) return

    const modelUrl = "/models/female_average.glb"
    const { dispose, loadPromise, scene, model } = modelLoader(canvasRef.current, modelUrl, 1.0, "bodyRearBtn")
    console.log('Loaded model:', model)
    // Apply shape keys once model is loaded
    loadPromise.then(() => {
         
      if (model) {
     
        model.traverse((child: any) => {
          if (child.isMesh && child.morphTargetInfluences) {
            const dict = child.morphTargetDictionary
            Object.entries(shapeKeyValues).forEach(([key, value]) => {
              if (dict[key] !== undefined) {
                child.morphTargetInfluences[dict[key]] = value
              }
            })
          }
        })
      }
    })

    loaderRef.current = { dispose, loadPromise, scene, model }

    return () => {
      loaderRef.current?.loadPromise.then(() => loaderRef.current?.dispose())
    }
  }, [])

  const handleShare = () => setShareDialogOpen(true)

  const handleSharePlatform = async (platform: string) => {
    const url = window.location.href
    const text = `Check out my 3D body model on MirrorMe Fashion! ${mockUserData.bodyType} shape with ${mockUserData.confidence}% accuracy.`

    try {
      switch (platform) {
        case "copy":
          await navigator.clipboard.writeText(url)
          toast({ title: "Link Copied", description: "The link has been copied to your clipboard." })
          break
        case "facebook":
          window.open(`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(url)}`, "_blank")
          break
        case "twitter":
          window.open(`https://twitter.com/intent/tweet?text=${encodeURIComponent(text)}&url=${encodeURIComponent(url)}`, "_blank")
          break
        case "instagram":
          await navigator.clipboard.writeText(text)
          toast({ title: "Text Copied", description: "Share text copied! You can paste it in Instagram." })
          break
        case "email":
          window.location.href = `mailto:?subject=My 3D Body Model&body=${encodeURIComponent(text + "\n\n" + url)}`
          break
      }
      setShareDialogOpen(false)
    } catch {
      toast({ title: "Share Failed", description: "Unable to share. Please try again.", variant: "destructive" })
    }
  }

  const handleDownload = async () => {
    try {
      const modelData = {
        user: mockUserData.name,
        bodyType: mockUserData.bodyType,
        measurements: mockUserData.measurements,
        confidence: mockUserData.confidence,
        createdAt: mockUserData.createdAt,
        lastUpdated: mockUserData.lastUpdated,
        bmi: mockUserData.bmi,
        bodyFat: mockUserData.bodyFat,
        muscleMass: mockUserData.muscleMass,
      }

      const dataBlob = new Blob([JSON.stringify(modelData, null, 2)], { type: "application/json" })
      const url = URL.createObjectURL(dataBlob)
      const link = document.createElement("a")
      link.href = url
      link.download = `${mockUserData.name.replace(/\s+/g, "_")}_body_model.json`
      document.body.appendChild(link)
      link.click()
      document.body.removeChild(link)
      URL.revokeObjectURL(url)

      toast({ title: "Export Successful", description: "Your body model data has been downloaded." })
    } catch {
      toast({ title: "Export Failed", description: "Unable to export data. Please try again.", variant: "destructive" })
    }
  }

  const handleSaveToFavorites = () => {
    setIsFavorited(!isFavorited)
    toast({
      title: isFavorited ? "Removed from Favorites" : "Added to Favorites",
      description: isFavorited
        ? "Your body model has been removed from favorites."
        : "Your body model has been saved to favorites.",
    })
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto p-4 lg:p-6">
        {/* Header */}
        <div className="mb-6">
          <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
            <div className="flex items-center gap-4">
              <Avatar className="h-16 w-16 lg:h-20 lg:w-20">
                <AvatarImage src={mockUserData.avatar || "/placeholder.svg"} alt={mockUserData.name} />
                <AvatarFallback className="bg-gradient-to-br from-red-500 to-red-600 text-white text-xl font-bold">
                  {mockUserData.name.split(" ").map((n) => n[0]).join("")}
                </AvatarFallback>
              </Avatar>
              <div>
                <h1 className="text-2xl lg:text-3xl font-bold text-gray-900">Your 3D Body Model</h1>
                <p className="text-gray-600 mt-1">Created on {new Date(mockUserData.createdAt).toLocaleDateString()}</p>
                <div className="flex items-center gap-2 mt-2">
                  <Badge variant="secondary" className="bg-red-100 text-red-700">
                    {mockUserData.bodyType} Shape
                  </Badge>
                  <Badge variant="outline" className="text-green-600 border-green-200">
                    {mockUserData.confidence}% Accuracy
                  </Badge>
                </div>
              </div>
            </div>

            <div className="flex flex-wrap gap-2">
              <Dialog open={shareDialogOpen} onOpenChange={setShareDialogOpen}>
                <DialogTrigger asChild>
                  <Button variant="outline" onClick={handleShare}>
                    <Share2 className="w-4 h-4 mr-2" />
                    Share
                  </Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-md">
                  <DialogHeader>
                    <DialogTitle>Share Your Body Model</DialogTitle>
                    <DialogDescription>Share your 3D body model with friends and family</DialogDescription>
                  </DialogHeader>
                  <div className="grid grid-cols-2 gap-3">
                    <Button variant="outline" onClick={() => handleSharePlatform("copy")} className="flex items-center gap-2">
                      <Copy className="w-4 h-4" /> Copy Link
                    </Button>
                    <Button variant="outline" onClick={() => handleSharePlatform("facebook")} className="flex items-center gap-2">
                      <Facebook className="w-4 h-4" /> Facebook
                    </Button>
                    <Button variant="outline" onClick={() => handleSharePlatform("twitter")} className="flex items-center gap-2">
                      <Twitter className="w-4 h-4" /> Twitter
                    </Button>
                    <Button variant="outline" onClick={() => handleSharePlatform("instagram")} className="flex items-center gap-2">
                      <Instagram className="w-4 h-4" /> Instagram
                    </Button>
                    <Button variant="outline" onClick={() => handleSharePlatform("email")} className="flex items-center gap-2 col-span-2">
                      <Mail className="w-4 h-4" /> Email
                    </Button>
                  </div>
                </DialogContent>
              </Dialog>

              <Button variant="outline" className="bg-red-600 text-white hover:bg-red-700 hover:text-white border-red-600" asChild>
                <Link href="/profile/body-shape/edit">
                  <Pencil className="w-4 h-4 mr-2" /> Model Edit
                </Link>
              </Button>

              <Button variant="outline" onClick={handleDownload}>
                <Download className="w-4 h-4 mr-2" /> Export
              </Button>
            </div>
          </div>
        </div>

        {/* Main Content */}
        {/* ... (rest of your JSX remains unchanged) */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* 3D Model Viewer */}
          <div className="lg:col-span-2">
            <Card className="h-fit">
              <CardHeader className="pb-4">
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="flex items-center gap-2">
                      <User className="w-5 h-5 text-red-600" /> 3D Body Model
                    </CardTitle>
                    <CardDescription>Interactive visualization of your body measurements</CardDescription>
                  </div>
                  <div className="flex items-center gap-2">
                    <Button variant="ghost" size="sm" onClick={() => setShowMeasurements(!showMeasurements)}>
                      {showMeasurements ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </Button>
                    <Button variant="ghost" size="sm" id="bodyRearBtn">
                      <RotateCcw className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="bg-gradient-to-br from-gray-100 to-gray-200 rounded-xl p-6 min-h-[500px] h-full flex items-center justify-center">
                  <canvas ref={canvasRef} className="w-full h-full" />
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Information Panel */}
         {/* Information Panel */}
<div className="space-y-6">
  {/* Quick Stats */}
  <Card>
    <CardHeader className="pb-4">
      <CardTitle className="flex items-center gap-2 text-lg">
        <Activity className="w-5 h-5 text-red-600" />
        Body Statistics
      </CardTitle>
    </CardHeader>
    <CardContent className="space-y-4">
      <div className="grid grid-cols-2 gap-4">
        <div className="text-center p-3 bg-gray-50 rounded-lg">
          <div className="text-2xl font-bold text-gray-900">{mockUserData.measurements.height}cm</div>
          <div className="text-sm text-gray-600">Height</div>
        </div>
        <div className="text-center p-3 bg-gray-50 rounded-lg">
          <div className="text-2xl font-bold text-gray-900">{mockUserData.measurements.weight}kg</div>
          <div className="text-sm text-gray-600">Weight</div>
        </div>
      </div>

      <div className="space-y-3">
        <div className="flex justify-between items-center">
          <span className="text-sm font-medium text-gray-700">BMI</span>
          <span className="text-sm font-bold text-green-600">{mockUserData.bmi}</span>
        </div>
        <Progress value={75} className="h-2" />

        <div className="flex justify-between items-center">
          <span className="text-sm font-medium text-gray-700">Body Fat</span>
          <span className="text-sm font-bold text-blue-600">{mockUserData.bodyFat}%</span>
        </div>
        <Progress value={mockUserData.bodyFat * 2} className="h-2" />

        <div className="flex justify-between items-center">
          <span className="text-sm font-medium text-gray-700">Muscle Mass</span>
          <span className="text-sm font-bold text-purple-600">{mockUserData.muscleMass}%</span>
        </div>
        <Progress value={mockUserData.muscleMass * 2} className="h-2" />
      </div>
    </CardContent>
  </Card>

  {/* Detailed Information Tabs */}
  <Card>
    <CardHeader className="pb-2">
      <CardTitle className="flex items-center gap-2 text-lg">
        <Info className="w-5 h-5 text-red-600" />
        Detailed Information
      </CardTitle>
    </CardHeader>
    <CardContent>
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="measurements" className="text-xs">
            Measurements
          </TabsTrigger>
          <TabsTrigger value="analysis" className="text-xs">
            Analysis
          </TabsTrigger>
          <TabsTrigger value="history" className="text-xs">
            History
          </TabsTrigger>
        </TabsList>

        <TabsContent value="measurements" className="mt-4 space-y-3">
          <div className="space-y-2">
            <div className="flex justify-between items-center py-2 border-b border-gray-100">
              <span className="text-sm text-gray-600">Bust</span>
              <span className="font-medium">{mockUserData.measurements.bust}"</span>
            </div>
            <div className="flex justify-between items-center py-2 border-b border-gray-100">
              <span className="text-sm text-gray-600">Waist</span>
              <span className="font-medium">{mockUserData.measurements.waist}"</span>
            </div>
            <div className="flex justify-between items-center py-2 border-b border-gray-100">
              <span className="text-sm text-gray-600">Hips</span>
              <span className="font-medium">{mockUserData.measurements.hips}"</span>
            </div>
            <div className="flex justify-between items-center py-2 border-b border-gray-100">
              <span className="text-sm text-gray-600">Shoulders</span>
              <span className="font-medium">{mockUserData.measurements.shoulders}"</span>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="analysis" className="mt-4 space-y-3">
          <div className="space-y-3">
            <div className="p-3 bg-red-50 rounded-lg">
              <div className="flex items-center gap-2 mb-2">
                <Target className="w-4 h-4 text-red-600" />
                <span className="font-medium text-red-900">Body Type Analysis</span>
              </div>
              <p className="text-sm text-red-700">
                You have an {mockUserData.bodyType.toLowerCase()} body shape with balanced proportions. This shape is characterized by similar bust and hip measurements with a defined waist.
              </p>
            </div>

            <div className="p-3 bg-blue-50 rounded-lg">
              <div className="flex items-center gap-2 mb-2">
                <TrendingUp className="w-4 h-4 text-blue-600" />
                <span className="font-medium text-blue-900">Recommendations</span>
              </div>
              <p className="text-sm text-blue-700">
                Based on your body type, we recommend clothing that emphasizes your waist and creates balanced silhouettes.
              </p>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="history" className="mt-4 space-y-3">
          <div className="space-y-3">
            <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
              <Calendar className="w-4 h-4 text-gray-600" />
              <div className="flex-1">
                <div className="font-medium text-sm">Model Created</div>
                <div className="text-xs text-gray-600">{new Date(mockUserData.createdAt).toLocaleDateString()}</div>
              </div>
            </div>

            <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
              <Calendar className="w-4 h-4 text-gray-600" />
              <div className="flex-1">
                <div className="font-medium text-sm">Last Updated</div>
                <div className="text-xs text-gray-600">{new Date(mockUserData.lastUpdated).toLocaleDateString()}</div>
              </div>
            </div>

            <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
              <Zap className="w-4 h-4 text-gray-600" />
              <div className="flex-1">
                <div className="font-medium text-sm">AI Analysis</div>
                <div className="text-xs text-gray-600">{mockUserData.confidence}% confidence score</div>
              </div>
            </div>
          </div>
        </TabsContent>
      </Tabs>
    </CardContent>
  </Card>

  {/* Action Buttons */}
  <Card>
    <CardHeader className="pb-4">
      <CardTitle className="flex items-center gap-2 text-lg">
        <Settings className="w-5 h-5 text-red-600" />
        Quick Actions
      </CardTitle>
    </CardHeader>
    <CardContent className="space-y-3">
      <Button variant="outline" className="w-full justify-start bg-transparent" asChild>
        <Link href="/profile/body-shape/edit">
          <Pencil className="w-4 h-4 mr-2" />
          Edit
        </Link>
      </Button>

      <Button variant="outline" className="w-full justify-start bg-transparent">
        Use Client
      </Button>

      <Button
        variant="outline"
        className="w-full justify-start bg-transparent"
        onClick={handleSaveToFavorites}
      >
        <Heart className={`w-4 h-4 mr-2 ${isFavorited ? "fill-red-500 text-red-500" : ""}`} />
        {isFavorited ? "Remove from Favorites" : "Save to Favorites"}
      </Button>

      <Button variant="outline" className="w-full justify-start bg-transparent" onClick={handleShare}>
        <Share2 className="w-4 h-4 mr-2" />
        Share Model
      </Button>
    </CardContent>
  </Card>
</div>

        </div>
      </div>
    </div>
  )
}
